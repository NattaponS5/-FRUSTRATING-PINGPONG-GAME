package player;
import java.awt.*;

import pong.GameFrame;


public class PlayerB extends GeneralPlayer {
    private int y = GameFrame.frame_HEIGHT / 2;
    private int yVelocity = 0;
    private int width = 10; //paddle
    private int height = 40; //paddle
    
    public PlayerB() {
    }
    
    public void updatePos() {
    	y = y + yVelocity;
    }

    public void paint(Graphics g) { //PaddleB
        g.setColor(Color.RED);
        g.fillRoundRect(GameFrame.frame_WIDTH - 30 - width, y, width, height,5,5); //reverse Player Pos
 }
    
    public void setYVelocity(int speed) {
        yVelocity = speed;
    }

    public int getX() { //lock at 500-30-10
        return (GameFrame.frame_WIDTH - 30 - width);
   }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;

    }

    public int getHeight() {
        return height;
    }
 
}