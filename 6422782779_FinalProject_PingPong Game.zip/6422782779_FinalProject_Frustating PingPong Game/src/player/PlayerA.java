package player;
import java.awt.Color;
import java.awt.Graphics;

import pong.GameFrame;

public class PlayerA extends GeneralPlayer{
    private int y = GameFrame.frame_HEIGHT / 2;
    private int yVelocity = 0;
    private int width = 10; //paddle
    private int height = 40; // paddle
    
    public PlayerA() {
    }
    
    public void updatePos() {
        y = y + yVelocity;
    }
    
    public void paint(Graphics g) { //paddleA
        g.setColor(Color.BLUE);
        g.fillRoundRect(20, y, width, height,5,5); //when the size changed, it wont affect the posY of paddle, to make sym
    }
    
    public void setYVelocity(int speed) {
        yVelocity = speed;
    }
    
    public int getX() { //lock at x=20
        return 20;
    }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }

}