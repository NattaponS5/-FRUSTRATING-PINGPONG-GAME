package player;

import java.awt.Graphics;

abstract class GeneralPlayer {
	GeneralPlayer(){
		
	}
	
	abstract void updatePos();
	abstract void paint(Graphics g);
	abstract void setYVelocity(int speed);
	abstract int getX();
	abstract int getY();
	abstract int getWidth();
	abstract int getHeight();
	
}
