package pong;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;



public class FirstPage {

	static int timeMS; //must run static
	static String selectedDiff ;
	static JButton butt_start = new JButton("START");
	static JLabel title = new JLabel("Frustrating Pingpong GAME");
	static JLabel chooseDiff = new JLabel("choose the difficulties");
	static JRadioButton butt_medium = new JRadioButton("MEDIUM");
	static JRadioButton butt_hard = new JRadioButton("HARD");
	static JLabel warning = new JLabel("P.S. This game is not easy :(");
	static boolean checkDiff = false;
	
	private static Ball ball = new Ball();
	
	FirstPage(){
		
	}
	
	public String getSelectedDiff() {
		return selectedDiff;
	}
	
	public int gettimeMS() {
		return timeMS;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame("Main Windows of PingPong game");
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setSize(700,340);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		title.setFont(new Font("Tahoma", Font.PLAIN, 32));
		title.setBounds(156, 25, 450, 48);
		frame.getContentPane().add(title);
		
		
		chooseDiff.setFont(new Font("Tahoma", Font.PLAIN, 18));
		chooseDiff.setBounds(242, 82, 182, 32);
		frame.getContentPane().add(chooseDiff);
		
		
		butt_medium.setFont(new Font("Tahoma", Font.PLAIN, 16));
		butt_medium.setBounds(193, 163, 182, 32);
		frame.getContentPane().add(butt_medium);
		butt_medium.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getSource() == butt_medium && e.getStateChange() == 1) {
					butt_hard.setSelected(false);
					butt_medium.setSelected(true);
					timeMS = 30;
					selectedDiff = "MEDIUM";
					checkDiff = true;
				}
			}
		});
		
		
		butt_hard.setFont(new Font("Tahoma", Font.PLAIN, 16));
		butt_hard.setBounds(385, 163, 182, 32);
		frame.getContentPane().add(butt_hard);
		butt_hard.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getSource() == butt_hard && e.getStateChange() == 1) {
					butt_hard.setSelected(true);
					butt_medium.setSelected(false);
					timeMS = 15;
					selectedDiff = "HARD";
					checkDiff = true;
				}
			}
		});
		
		butt_start.setFont(new Font("Tahoma", Font.PLAIN, 26));
		butt_start.setBounds(255, 213, 140, 32);
		frame.getContentPane().add(butt_start);
		butt_start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (checkDiff) {
				new GameFrame("Pingpong Game");
				RightPanel.textArea1.setText(" Ball is making (atan) " + Math.round(ball.getStartDegree() * 100.0) /100.0 + "°\n Initial X-Velocity = "+ Math.round(ball.getXInitial() * 100.0)/100.0 + "\n Initial Y-Velocity = " + Math.round(ball.getYInitial() *100.0) / 100.0);
				}
			}
		});
		
		warning.setFont(new Font("Tahoma", Font.PLAIN, 16));
		warning.setBounds(227, 119, 221, 28);
		frame.getContentPane().add(warning);
		frame.setVisible(true);
	}
}
