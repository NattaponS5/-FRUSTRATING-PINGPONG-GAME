package pong;

import java.awt.*;
import javax.swing.*;



public class GameFrame extends JFrame  {
	public static int frame_WIDTH = 500; //final all the same
	public static int frame_HEIGHT = 340; // final


  public GameFrame(String title) {
	  super(title);
	  this.getContentPane().add(new GamePanel(), BorderLayout.CENTER);
	  this.getContentPane().add(new RightPanel(), BorderLayout.EAST);
	  
      this.setSize(frame_WIDTH+200, frame_HEIGHT); //extends east for 200 for right panel
 
      this.setLocationRelativeTo(null);
      this.setResizable(false);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setVisible(true);

    }
}

