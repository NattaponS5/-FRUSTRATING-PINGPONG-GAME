package pong;

import java.awt.*;
import javax.swing.*;

public class RightPanel extends JPanel{
	
	public JLabel welc = new JLabel("   Welcome to 'PING PONG' game");
	public JLabel warn = new JLabel("    P.S. This game is not easy! :(");
	public JLabel howStupid = new JLabel("See how stupid you are ↓ ;)");
	public JLabel learn = new JLabel("Let learn some Math!");
	public JLabel blank = new JLabel("");// for space
	
	Ball ball = new Ball();
	GamePanel game = new GamePanel();
	FirstPage firpage = new FirstPage();
	
	public static JTextArea textArea1 = new JTextArea("");
	//JTextArea textArea2 = new JTextArea("Player" + game.getWinSide() + " WINSSSSSS, CONGRATS!");
	JTextArea textArea3 = new JTextArea("     You have chosen your fate on  \n                '" + firpage.getSelectedDiff() +"' Mode         ");
	
	
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	
	//BufferedImage myPicture = ImageIO.read(new File("C:\\Users\\Asus\\eclipse-workspace\\6422782779_Project2_Blaming PingPong Game\\troll-face.png"));
	//JLabel picLabel = new JLabel(new ImageIcon(myPicture));
	
	
	public RightPanel() {
		this.setLayout(new BorderLayout());
		
		JPanel welcPanel = new JPanel(new GridLayout(3,1));
		welcPanel.add(welc);
		welcPanel.add(warn);
		welcPanel.add(textArea3);
		p1.add(welcPanel);
		
		
		JPanel diffPanel = new JPanel(new GridLayout(3,1));
		diffPanel.add(blank);
		diffPanel.add(howStupid);
		//diffPanel.add(picLabel);
		p2.add(diffPanel);
		
		JPanel learnPanel = new JPanel(new GridLayout(2,1));
		learnPanel.add(blank);
		learnPanel.add(learn);
		p3.add(learnPanel);
		
		JPanel center1 = new JPanel(new BorderLayout());
		center1.add(p2, BorderLayout.CENTER);
		
		JPanel center2 = new JPanel(new BorderLayout());
		center2.add(p3, BorderLayout.NORTH);
		center2.add(textArea1, BorderLayout.CENTER);
		
		p4.add(center1);
		p5.add(center2);
		
		
		
		
		this.add(p1, BorderLayout.NORTH);
		this.add(p4, BorderLayout.CENTER);
		this.add(p5, BorderLayout.SOUTH);

	}
}
