package pong;
import java.awt.*;

import java.util.Random;

import player.PlayerA;
import player.PlayerB;
import java.lang.Math;


public class Ball {
    private int x =  GameFrame.frame_WIDTH / 2;
    private int y = GameFrame.frame_HEIGHT / 2;

    
    private Random rand = new Random();
    int[] Xarr = new int[] { 4,5,-4,-5,};
    int[] Yarr = new int[] { 4,5,-4,-5,};
    private int xVelocity = Xarr[rand.nextInt(Xarr.length)]; //velocity of ball
    private int yVelocity = Yarr[rand.nextInt(Yarr.length)] ; //velocity of ball
    private double xInitial =  xVelocity;
    private double yInitial =  yVelocity;
    
    private double startradian = Math.atan((double)yVelocity / (double)xVelocity);
    private double startdegree = Math.abs(Math.toDegrees(startradian));
    
    private int size = 7; //ball size
    private int playerAScore = 0; //not static
    private int playerBScore = 0;
    

    
    Font myfont = new Font("Arial", Font.BOLD, 16);

    public Ball() {
  
    	}
    
    
    public void updatePos() {
    	//System.out.println("ball is moving " + x + " " + y);
        x = x + xVelocity;
        y = y + yVelocity;

        
        if (x < -1) {
            playerBScore++;
        	}
        else if (x > GameFrame.frame_WIDTH - 20) { 
        	playerAScore++;
        	}
        }  
    
    public void paint(Graphics g) {
        g.setColor(Color.WHITE); //paint ball
        g.fillOval(x, y, size, size);
        
        //score board
        g.setColor(Color.YELLOW);
        g.setFont(myfont);
        g.drawString(strtoA(), 5, 15);
        g.drawString(strtoB(), (GameFrame.frame_WIDTH/2) + 5, 15); // 5 away from L Center border
    }
    
    private void reverseDirX() {
        xVelocity = -xVelocity;
   }
 
    private void reverseDirY() {
        yVelocity = -yVelocity;
    }
 
    public void checkCollisionWith(PlayerA a) { // this.x from updatePos
        if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(a.getX(), a.getY(), a.getWidth(), a.getHeight()))) {
        	reverseDirX(); //hit A
        }
        if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(a.getX(), a.getY()-1, a.getWidth(), 1))) { 
            reverseDirY(); //hit top A
        }
        if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(a.getX(), a.getY()+a.getHeight(), a.getWidth(), 1))) { 
            reverseDirY(); //hit bottom A
        }
    }
    
    public void checkCollisionWith(PlayerB b) {

        if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(b.getX(), b.getY(), b.getWidth(), b.getHeight()))) {
            reverseDirX(); //hit B
        }
        if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(b.getX(), b.getY()-1, b.getWidth(), 1))) { 
            reverseDirY(); //hit top B
        }
        if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(b.getX(), b.getY()+b.getHeight(), b.getWidth(), 1))) {
            reverseDirY(); //hit bottom B
        }
    }
    
    public void checkNewWall(PlayerA a) {
    	if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(240, 30, 20, GameFrame.frame_HEIGHT - 72))) {
        	reverseDirX();
    	}
    }
    
    public void checkNewWall(PlayerB b) {
    	 if (new Rectangle(this.x, this.y, size, size ).intersects(new Rectangle(241, 30, 22, GameFrame.frame_HEIGHT - 72))) {
             reverseDirX();
    	 }
    }
    
    
    public void hitWall() {
        if (this.y < 32 || this.y > GameFrame.frame_HEIGHT - 50) { //30+2 line width top bottom
            reverseDirY();
        }
        if (this.x < 0) { //left right side
        	reverseDirX();
        	
        }
        if (this.x > GameFrame.frame_WIDTH - 20) {
        	reverseDirX();
      
        }
    }

    public int getX() { //pos of ball
        return x;
    }

    public int getY() {
        return y;
    }
    
    public double getXInitial() {
    	return xInitial;
    }
    
    public double getYInitial() {
    	return yInitial;
    }

    public int getPlayerAScore() {
       return playerAScore;
        }
    
    public int getPlayerBScore() {
        return playerBScore;
    }
    
    public double getStartDegree() {
    	return startdegree;
    }
    
    public String strtoA() {
        String retA = ""; //set to String
        retA = "PlayerA Score: " + playerAScore;
        return retA;
    }
    public String strtoB() {
        String retB = ""; // set to String
        retB = "PlayerB Score: " + playerBScore;
        return retB;
    }

}