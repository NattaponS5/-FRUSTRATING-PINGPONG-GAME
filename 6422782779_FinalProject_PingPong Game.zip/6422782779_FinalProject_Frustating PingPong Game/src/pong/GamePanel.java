package pong;

import java.awt.*;

import java.awt.event.*;
import javax.swing.*;

import player.PlayerA;
import player.PlayerB;

import wall.wallMap;


public class GamePanel extends JPanel implements ActionListener, KeyListener  {

	
    PlayerA pA = new PlayerA();
    Ball ball = new Ball();
    PlayerB pB = new PlayerB();
    FirstPage first = new FirstPage();
    Timer timer1 = new Timer(first.gettimeMS() , this);
    
	public static boolean drawWall = false;
	public static boolean timerCountdown = false;
	public static boolean exit = false;
    
	wallMap map = new wallMap();// make wall enemy
	

    public GamePanel() {
    	timer1.start(); //to start the ball and paddle

        this.addKeyListener(this); // if not add, paddle not move

        this.setFocusable(true); // if not set here, cant see paddle move
       
        

        
    }

    private void updateAllPos() {

        pA.updatePos(); //paddle
        pB.updatePos(); //paddle
        ball.updatePos();//ball
        
 
        ball.checkCollisionWith(pA);
        ball.checkCollisionWith(pB);
        ball.hitWall();
        
        if(drawWall) {
        	if (ball.getX() <240) {
        	ball.checkNewWall(pA);
        	}
        	else if (ball.getX() > 250) {
        	ball.checkNewWall(pB);
        	}
        }

    }  


    protected void paintComponent(Graphics g) {
        g.setColor(Color.BLACK); //set field color
        g.fillRect(0, 0, GameFrame.frame_WIDTH-10, GameFrame.frame_HEIGHT);
  
        map.paint(g);
        g.setColor(Color.WHITE);
        if(timerCountdown) {
        	g.setFont(new Font("Arial", Font.BOLD, 16));
        	g.drawString("Wall is going away in "+ map.getSecond(), 30, 50);
        	g.drawString("Wall is going away in "+ map.getSecond(), 280, 50);
        }
       // map.TimeCountdown();
        pA.paint(g); // add in this panel
        pB.paint(g);
        ball.paint(g);
        
        g.setColor(Color.WHITE); //line in field
        g.drawLine(0, 30, GameFrame.frame_WIDTH, 30); //top line
        g.drawLine(GameFrame.frame_WIDTH / 2, 30, GameFrame.frame_WIDTH / 2, GameFrame.frame_HEIGHT); //bottom line
        g.drawOval((GameFrame.frame_WIDTH / 2) - 30, GameFrame.frame_HEIGHT / 2 - 30, 60, 60); // center field
            
        if (ball.getPlayerAScore() >= 20 || ball.getPlayerBScore() >= 20) {
    	  exit = true;
    	  g.setFont(new Font("Arial", Font.BOLD, 18));
    	  g.setColor(Color.WHITE);
    	  g.drawString(""+ball.getPlayerAScore()+ "          " + ball.getPlayerBScore(), 210,280);
    	  g.setFont(new Font("Arial", Font.PLAIN, 14));
    	  
    	  if (ball.getPlayerAScore() >  ball.getPlayerBScore()){
    		  g.drawString("PlayerA congratss! ", 30, 90);
    		  g.drawString("YOU WIN!", 30, 120);
    		  g.drawString("Poor You! PlayerB ", 280, 90);
    		  g.drawString("You stupid!",280,120);
    	  }
    	  else if (ball.getPlayerBScore() >  ball.getPlayerAScore()){
    		  g.drawString("Poor you! PlayerA", 30, 90);
    		  g.drawString("You stupid!", 30, 120);
    		  g.drawString("PlayerB congratss! ", 280, 90);
    		  g.drawString("YOU WIN!",280,120);
    	  }
        }
    }


	public void actionPerformed(ActionEvent e) {
 
    	if (e.getSource() == timer1) {
    		//System.out.println("CHECK BALL POS " + ball.getX() + " " + ball.getY() + "n");
    		updateAllPos();
    		repaint();
    	}
    	if (exit) {
         	timer1.stop();
         }
    }
 

    public void keyPressed(KeyEvent e) {
    	//if (e.getSource() == timer1) { //uncommented to move ws up down
		       if (e.getKeyCode() == KeyEvent.VK_W) {
		    	   //System.out.println("w");
		           pA.setYVelocity(-4);
		            if (pA.getY() <= 32) {
		                pA.setYVelocity(0); //stop move up
		            }
		        } 
		       else if (e.getKeyCode() == KeyEvent.VK_S) {
		    	   //System.out.println("s");
		           pA.setYVelocity(4);
		           if (pA.getY() + 40 > GameFrame.frame_HEIGHT - 40) {
		                pA.setYVelocity(0); // stop move down
		           }
		        }
		       if (e.getKeyCode() == KeyEvent.VK_UP) {
		    	   //System.out.println("up");
		           pB.setYVelocity(-4);
		           if (pB.getY() <= 32) {
		               pB.setYVelocity(0); //stop move up
		           }
		        } 
		       else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
		    	   //System.out.println("down");
		           pB.setYVelocity(4);
		           if (pB.getY() + 40 > GameFrame.frame_HEIGHT - 40) {
		               pB.setYVelocity(0); // stop move down
		           }
		       }
		       if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    	   drawWall = true;
		    	   timerCountdown = true;
		       }
		       if (e.getKeyCode() == KeyEvent.VK_Q) {
		    	   drawWall = true;
		    	   timerCountdown = true;
		       }
    	//}
    }

   public void keyReleased(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_W || e.getKeyCode() == KeyEvent.VK_S) {
            pA.setYVelocity(0);
        }
        if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) {
            pB.setYVelocity(0);
        }
    }

    public void keyTyped(KeyEvent e) {

    }
    public boolean getExit() {
    	return exit;
    }
    
}


