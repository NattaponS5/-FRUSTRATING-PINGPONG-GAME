package wall;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

import pong.GameFrame;
import pong.GamePanel;

public class wallMap implements ActionListener{
	Timer timer2 = new Timer(2000, this);
	public int brickWidth = 22;
	public int brickHeight =268;
	
	static int second = 10;
	boolean removeWall = false;
	public wallMap() {
		if (second == 10) {
			timer2.start();
		}
		if (second == 0) {
			timer2.stop();
		}
	}
	
	public void actionPerformed(ActionEvent e) {
		if (GamePanel.timerCountdown) {
			second = second -1;
			System.out.println(second);
		}
		if (second == 0) {
			removeWall = true; //repaint it with black color
			GamePanel.drawWall = false; //stop center wall
			GamePanel.timerCountdown = false;
			second = 10;
		}
	}
		
	public void paint(Graphics g) {
		if (GamePanel.drawWall) {
			g.setColor(Color.GRAY);
			g.fillRect(239, 33, brickWidth, GameFrame.frame_HEIGHT - 72);
		}
		else if(removeWall) {
			g.setColor(Color.BLACK);
			g.fillRect(239, 33, brickWidth, GameFrame.frame_HEIGHT - 72);
		}
		
	}
	
	public int getbrickWidth() {
		return brickWidth;
	}
	public int getbrickHeight() {
		return brickHeight;
	}
	public int getSecond() {
		return second;
	}
	
}
